"""
TEN SECONDS: ZOMBIES  -  Blender model builder
===============================================
Builds the zombie characters in Blender (smooth subdivided bodies, torn
clothes, faces with sunken eyes, teeth, hats...) and exports one .glb file
per zombie into a folder called  zombie_models  next to this script.
The Python game (ten_seconds_zombies.py) loads them automatically.

Run it with Blender (no need to open the Blender window):
    blender --background --python make_zombies_blender.py

Every body part is exported as its own node (head, jaw, upperarm_n, ...)
with its pivot at the joint, so the game can animate the zombie.
Coordinates below are written in the GAME's space: y = up, z = forward.
"""
import math
import random
from pathlib import Path

import bpy
import bmesh

OUT = Path(__file__).resolve().parent / 'zombie_models'


# ----------------------------------------------------------------------
# small helpers
# ----------------------------------------------------------------------
def to_blender(v):
    """game (x, y-up, z-forward)  ->  blender (x, y-forward, z-up)"""
    return (v[0], v[2], v[1])


def hexc(h, k=1.0):
    h = h.lstrip('#')
    return tuple(min(1.0, int(h[i:i + 2], 16) / 255 * k) for i in (0, 2, 4))


def mix(a, b, t):
    return tuple(a[i] + (b[i] - a[i]) * t for i in range(3))


def _hash(ix, iy, iz, seed):
    n = (ix * 374761393 + iy * 668265263 + iz * 2147483647 + seed * 144269) & 0xFFFFFFFF
    n = (n ^ (n >> 13)) * 1274126177 & 0xFFFFFFFF
    return ((n ^ (n >> 16)) & 0xFFFF) / 65535.0


def noise3(x, y, z, seed=0):
    ix, iy, iz = math.floor(x), math.floor(y), math.floor(z)
    fx, fy, fz = x - ix, y - iy, z - iz
    fx, fy, fz = fx * fx * (3 - 2 * fx), fy * fy * (3 - 2 * fy), fz * fz * (3 - 2 * fz)
    def h(a, b, c): return _hash(ix + a, iy + b, iz + c, seed)
    x00 = h(0, 0, 0) + (h(1, 0, 0) - h(0, 0, 0)) * fx
    x10 = h(0, 1, 0) + (h(1, 1, 0) - h(0, 1, 0)) * fx
    x01 = h(0, 0, 1) + (h(1, 0, 1) - h(0, 0, 1)) * fx
    x11 = h(0, 1, 1) + (h(1, 1, 1) - h(0, 1, 1)) * fx
    y0 = x00 + (x10 - x00) * fy
    y1 = x01 + (x11 - x01) * fy
    return y0 + (y1 - y0) * fz


def fbm(p, scale, seed=0, octaves=3):
    v, a, f = 0, 0.5, scale
    for o in range(octaves):
        v += a * noise3(p[0] * f, p[1] * f, p[2] * f, seed + o * 17)
        a *= 0.5; f *= 2.1
    return v / 0.875


# ----------------------------------------------------------------------
# mesh generators (game coordinates)
# ----------------------------------------------------------------------
def lathe(rings, seg=16, cap_top=True, cap_bottom=True):
    """rings: list of (cx, cy, cz, rx, rz) from top to bottom, around the y axis"""
    verts, faces = [], []
    for (cx, cy, cz, rx, rz) in rings:
        for s in range(seg):
            a = s / seg * math.tau
            verts.append((cx + math.sin(a) * rx, cy, cz + math.cos(a) * rz))
    for r in range(len(rings) - 1):
        for s in range(seg):
            a = r * seg + s; b = r * seg + (s + 1) % seg
            faces.append((a, b, b + seg, a + seg))
    if cap_top:
        c = rings[0]; verts.append((c[0], c[1] + 0.002, c[2])); ci = len(verts) - 1
        for s in range(seg): faces.append((ci, (s + 1) % seg, s))
    if cap_bottom:
        c = rings[-1]; base = (len(rings) - 1) * seg; verts.append((c[0], c[1] - 0.002, c[2])); ci = len(verts) - 1
        for s in range(seg): faces.append((ci, base + s, base + (s + 1) % seg))
    return verts, faces


def limb(top, length, r0, r1, seg=14, bulge=0.0, flat=1.0, rings=7):
    """tapered limb hanging straight down from 'top'"""
    rr = []
    for i in range(rings):
        t = i / (rings - 1)
        r = r0 + (r1 - r0) * t + math.sin(t * math.pi) * bulge
        rr.append((top[0], top[1] - t * length, top[2], r, r * flat))
    return lathe(rr, seg)


def sphere(c, r, seg=20, rings=14, deform=None):
    verts, faces = [], []
    for i in range(rings + 1):
        th = i / rings * math.pi
        for s in range(seg):
            ph = s / seg * math.tau
            v = [math.sin(th) * math.sin(ph) * r[0], math.cos(th) * r[1], math.sin(th) * math.cos(ph) * r[2]]
            if deform: v = deform(v)
            verts.append((c[0] + v[0], c[1] + v[1], c[2] + v[2]))
    for i in range(rings):
        for s in range(seg):
            a = i * seg + s; b = i * seg + (s + 1) % seg
            faces.append((a, a + seg, b + seg, b))
    return verts, faces


def box(c, size):
    x, y, z = size[0] / 2, size[1] / 2, size[2] / 2
    v = [(c[0] + sx * x, c[1] + sy * y, c[2] + sz * z) for sx in (-1, 1) for sy in (-1, 1) for sz in (-1, 1)]
    f = [(0, 1, 3, 2), (4, 6, 7, 5), (0, 4, 5, 1), (2, 3, 7, 6), (0, 2, 6, 4), (1, 5, 7, 3)]
    return v, f


# ----------------------------------------------------------------------
# blender objects
# ----------------------------------------------------------------------
MATS = {}


def material(name, emissive=None, rough=0.8):
    if name in MATS: return MATS[name]
    m = bpy.data.materials.new(name); m.use_nodes = True
    bsdf = m.node_tree.nodes.get('Principled BSDF')
    bsdf.inputs['Roughness'].default_value = rough
    attr = m.node_tree.nodes.new('ShaderNodeVertexColor'); attr.layer_name = 'Col'
    m.node_tree.links.new(attr.outputs['Color'], bsdf.inputs['Base Color'])
    if emissive:
        bsdf.inputs['Emission Color'].default_value = (*emissive, 1)
        bsdf.inputs['Emission Strength'].default_value = 3.0
    MATS[name] = m
    return m


def make_obj(name, parent, vf, colfn, mat='skin', subsurf=1, lumpy=0.0, holes=0.0, seed=0, flip=False):
    verts, faces = vf
    bverts = [to_blender(v) for v in verts]
    bfaces = [tuple(reversed(f)) for f in faces] if not flip else faces  # axis swap flips winding
    me = bpy.data.meshes.new(name)
    me.from_pydata(bverts, [], bfaces); me.validate(); me.update()
    ob = bpy.data.objects.new(name, me)
    bpy.context.scene.collection.objects.link(ob)
    if subsurf:
        md = ob.modifiers.new('sub', 'SUBSURF'); md.levels = subsurf; md.render_levels = subsurf
        dg = bpy.context.evaluated_depsgraph_get()
        new = bpy.data.meshes.new_from_object(ob.evaluated_get(dg))
        ob.modifiers.clear(); old = ob.data; ob.data = new; bpy.data.meshes.remove(old)
        me = ob.data
    bm = bmesh.new(); bm.from_mesh(me)
    bm.normal_update()
    if lumpy:
        for v in bm.verts:
            g = (v.co.x, v.co.z, v.co.y)
            v.co += v.normal * (fbm(g, 14, seed) - 0.5) * lumpy
    if holes:
        kill = []
        for f in bm.faces:
            c = f.calc_center_median(); g = (c.x, c.z, c.y)
            if noise3(g[0] * 22, g[1] * 22, g[2] * 22, seed + 5) > 1 - holes:
                kill.append(f)
        bmesh.ops.delete(bm, geom=kill, context='FACES')
    bm.normal_update()
    bm.to_mesh(me); bm.free()
    for p in me.polygons: p.use_smooth = True
    # vertex colours
    attr = me.color_attributes.new('Col', 'FLOAT_COLOR', 'POINT')
    for i, v in enumerate(me.vertices):
        g = (v.co.x, v.co.z, v.co.y)
        n = (v.normal.x, v.normal.z, v.normal.y)
        c = colfn(g, n)
        attr.data[i].color = (c[0], c[1], c[2], 1.0)
    me.color_attributes.active_color = attr
    me.materials.append(material(mat, emissive=(1, 0.85, 0.3) if mat == 'glow' else ((0.6, 1, 0.2) if mat == 'acid' else None),
                                 rough=0.95 if mat == 'cloth' else 0.6))
    ob.parent = parent
    return ob


def empty(name, parent=None):
    e = bpy.data.objects.new(name, None)
    bpy.context.scene.collection.objects.link(e)
    e.parent = parent
    return e


# ----------------------------------------------------------------------
# colour functions
# ----------------------------------------------------------------------
def skin_fn(base, seed):
    b = hexc(base)
    bruise = hexc('#4b2a4a'); rot = hexc('#5a3a1a'); blood = hexc('#5c1414')
    def f(p, n):
        m = fbm(p, 9, seed)
        c = mix(b, mix(b, (0, 0, 0), 0.35), max(0, m - 0.45) * 1.6)
        br = fbm(p, 4, seed + 3)
        if br > 0.62: c = mix(c, bruise, min(1, (br - 0.62) * 4))
        if fbm(p, 6, seed + 9) > 0.7: c = mix(c, rot, 0.55)
        if noise3(p[0] * 30, p[1] * 30, p[2] * 30, seed + 11) > 0.93: c = mix(c, blood, 0.8)
        vein = abs(noise3(p[0] * 18, p[1] * 18, p[2] * 18, seed + 21) - 0.5)
        if vein < 0.02: c = mix(c, hexc('#3d2656'), 0.5)
        return c
    return f


def cloth_fn(base, seed, dirt_below=0.5):
    b = hexc(base)
    def f(p, n):
        m = fbm(p, 12, seed)
        c = mix(b, (0, 0, 0), max(0, m - 0.5) * 0.9)
        c = mix(c, mix(c, (1, 1, 1), 0.15), max(0, 0.45 - m))
        d = fbm(p, 5, seed + 2)
        if d > 0.6: c = mix(c, hexc('#3b2a17'), min(0.7, (d - 0.6) * 3))
        if p[1] < dirt_below: c = mix(c, hexc('#2a2015'), min(0.6, (dirt_below - p[1]) * 1.4))
        if noise3(p[0] * 25, p[1] * 25, p[2] * 25, seed + 8) > 0.94: c = mix(c, hexc('#4a1010'), 0.7)
        return c
    return f


def solid(h):
    c = hexc(h)
    return lambda p, n: c


# ----------------------------------------------------------------------
# zombie builder
# ----------------------------------------------------------------------
SKIN = {'walker': '#8ea56a', 'runner': '#a9b389', 'spitter': '#9cc35a', 'brute': '#6d8a4f'}


def build(ztype, outfit, top_hex, bot_hex, seed):
    rnd = random.Random(seed)
    bpy.ops.wm.read_factory_settings(use_empty=True)
    MATS.clear()
    thin = 0.85 if ztype == 'runner' else 1.0
    bulk = 1.35 if ztype == 'brute' else 1.0
    skin = skin_fn(SKIN[ztype], seed)
    top = cloth_fn(top_hex, seed + 1) if top_hex else skin
    bot = cloth_fn(bot_hex, seed + 2, dirt_below=0.55)
    root = empty('zombie')

    # ---------------- body (pivot 0, 0.9, 0) ----------------
    body = empty('body', root)
    belly_z = 0.1 if ztype == 'spitter' else 0.0
    trs = [(0, 1.62, 0.0, 0.055, 0.055), (0, 1.56, 0.0, 0.08, 0.075), (0, 1.5, 0.0, 0.2 * bulk, 0.12 * bulk),
           (0, 1.44, 0.0, 0.25 * thin * bulk, 0.14 * bulk), (0, 1.32, 0.01, 0.24 * thin * bulk, 0.15 * bulk),
           (0, 1.18, 0.0 + belly_z * 0.6, 0.21 * thin * bulk, 0.14 * bulk + belly_z * 0.6),
           (0, 1.06, 0.0 + belly_z, 0.19 * thin * bulk, 0.13 * bulk + belly_z), (0, 0.96, 0, 0.18 * thin * bulk, 0.12 * bulk),
           (0, 0.86, 0, 0.17 * bulk, 0.115 * bulk)]
    make_obj('torso_skin', body, lathe(trs, 18), skin, 'skin', 1, lumpy=0.012, seed=seed)
    make_obj('neck', body, limb((0, 1.72, 0.02), 0.16, 0.058, 0.066, 12), skin, 'skin', 1, seed=seed)
    if outfit != 'bare':
        shirt = [(x, y, z, rx * 1.07 + 0.006, rz * 1.08 + 0.006) for (x, y, z, rx, rz) in trs[2:-1]]
        shirt = [(0, 1.55, 0, 0.12, 0.1)] + shirt
        # ragged hem
        sv, sf = lathe(shirt, 18, cap_top=False, cap_bottom=False)
        seg = 18; last = (len(shirt) - 1) * seg
        for s in range(seg):
            x, y, z = sv[last + s]; sv[last + s] = (x, y - rnd.uniform(0, 0.07), z)
        make_obj('shirt', body, (sv, sf), top, 'cloth', 1, lumpy=0.01, holes=0.16, seed=seed + 4)
    pants = [(0, 1.0, 0, 0.185 * thin * bulk, 0.125 * bulk), (0, 0.9, 0, 0.18 * bulk, 0.12 * bulk), (0, 0.8, 0, 0.17 * bulk, 0.115 * bulk)]
    make_obj('pants_top', body, lathe(pants, 18, cap_top=False), bot, 'cloth', 1, seed=seed + 5)
    fz = 0.15 * bulk + 0.012
    if outfit == 'suit':
        make_obj('collar', body, box((0, 1.45, fz - 0.01), (0.13, 0.12, 0.02)), solid('#d8d8d0'), 'cloth', 0)
        tv = [(0, 1.47, fz + 0.01), (0.03, 1.43, fz + 0.012), (0.035, 1.18, fz + 0.03), (0, 1.12, fz + 0.035), (-0.035, 1.18, fz + 0.03), (-0.03, 1.43, fz + 0.012)]
        make_obj('tie', body, (tv + [(x, y, z - 0.012) for (x, y, z) in tv], [(0, 1, 2, 3, 4, 5), (11, 10, 9, 8, 7, 6)] + [(i, (i + 1) % 6, (i + 1) % 6 + 6, i + 6) for i in range(6)]),
                 cloth_fn('#991b1b', seed + 6), 'cloth', 0)
        for k in range(3):
            make_obj(f'button{k}', body, sphere((0.05, 1.32 - k * 0.1, fz + 0.01), (0.012, 0.012, 0.006), 8, 6), solid('#111111'), 'cloth', 0)
    elif outfit == 'guard':
        make_obj('badge', body, box((0.11, 1.38, fz + 0.005), (0.055, 0.065, 0.012)), solid('#d4a23a'), 'skin', 0)
        make_obj('belt', body, lathe([(0, 0.99, 0, 0.2, 0.135), (0, 0.94, 0, 0.2, 0.135)], 18, False, False), solid('#121212'), 'cloth', 0)
        make_obj('buckle', body, box((0, 0.965, 0.14), (0.06, 0.045, 0.012)), solid('#b8b8b8'), 'skin', 0)
    elif outfit == 'worker':
        vest = [(x, y, z, rx * 1.12 + 0.012, rz * 1.12 + 0.012) for (x, y, z, rx, rz) in trs[3:-2]]
        make_obj('vest', body, lathe(vest, 18, False, False), cloth_fn('#f97316', seed + 7), 'cloth', 1, holes=0.08, seed=seed + 7)
        for y in (1.12, 1.3):
            make_obj(f'stripe{y}', body, lathe([(0, y + 0.02, 0.01, 0.265, 0.18), (0, y - 0.02, 0.01, 0.26, 0.175)], 18, False, False), solid('#e8e8e8'), 'glow', 0)
    elif outfit == 'bare':
        for sx in (-1, 1):
            make_obj(f'pec{sx}', body, sphere((sx * 0.1, 1.36, 0.14 * bulk), (0.12, 0.08, 0.06), 14, 10), skin, 'skin', 0, seed=seed)
        for k in range(3):
            for sx in (-1, 1):
                make_obj(f'ab{k}{sx}', body, sphere((sx * 0.05, 1.2 - k * 0.07, 0.15 * bulk), (0.045, 0.03, 0.025), 10, 8), skin, 'skin', 0, seed=seed)
        for k in range(3):
            make_obj(f'scar{k}', body, box((0.06, 1.25 + k * 0.05, 0.19 * bulk), (0.15, 0.018, 0.02)), solid('#5b2020'), 'skin', 0)
    if ztype == 'spitter':
        make_obj('sac', body, sphere((0, 1.1, 0.13), (0.24, 0.22, 0.2), 20, 14, deform=lambda v: [v[0], v[1], v[2] * (1 + 0.15 * math.sin(v[1] * 30))]),
                 lambda p, n: mix(hexc('#b8ff4a'), hexc('#3f8f00'), fbm(p, 10, seed)), 'acid', 1)
        for k in range(9):
            a = rnd.uniform(-1.3, 1.3); y = 1.1 + rnd.uniform(-0.16, 0.16)
            make_obj(f'pust{k}', body, sphere((math.sin(a) * 0.23, y, 0.13 + math.cos(a) * 0.2), (0.03,) * 3, 8, 6), solid('#eaff9a'), 'acid', 0)

    # ---------------- legs ----------------
    for sx, nm in ((-1, 'n'), (1, 'p')):
        hx = sx * 0.11 * bulk
        thigh = empty(f'thigh_{nm}', root)
        make_obj(f'thigh_{nm}_m', thigh, limb((hx, 0.92, 0), 0.48, 0.09 * thin * bulk, 0.072 * thin * bulk, 14, bulge=0.012), bot, 'cloth', 1, lumpy=0.006, holes=0.1, seed=seed + 10 + sx)
        make_obj(f'thigh_{nm}_s', thigh, limb((hx, 0.9, 0), 0.46, 0.08 * thin * bulk, 0.064 * thin * bulk, 12), skin, 'skin', 0, seed=seed)
        shin = empty(f'shin_{nm}', root)
        if ztype == 'brute':
            make_obj(f'shin_{nm}_m', shin, limb((hx, 0.44, 0), 0.4, 0.075 * bulk, 0.055 * bulk, 14, bulge=0.015), skin, 'skin', 1, lumpy=0.008, seed=seed)
            make_obj(f'shorts_{nm}', shin, limb((hx, 0.48, 0), 0.08, 0.088 * bulk, 0.085 * bulk, 14), bot, 'cloth', 1, holes=0.2, seed=seed + 12)
            make_obj(f'foot_{nm}', shin, sphere((hx, 0.03, 0.05), (0.07 * bulk, 0.04, 0.14), 14, 10), skin, 'skin', 0)
        else:
            make_obj(f'shin_{nm}_m', shin, limb((hx, 0.45, 0), 0.4, 0.072 * thin, 0.058 * thin, 14), bot, 'cloth', 1, holes=0.12, seed=seed + 14 + sx)
            make_obj(f'shin_{nm}_s', shin, limb((hx, 0.44, 0), 0.38, 0.062 * thin, 0.05 * thin, 12), skin, 'skin', 0)
            shoe_c = solid('#1a1410') if outfit in ('suit', 'guard') else cloth_fn('#3a3a3a', seed)
            make_obj(f'shoe_{nm}', shin, sphere((hx, 0.04, 0.05), (0.065, 0.045, 0.135), 14, 10, deform=lambda v: [v[0], max(v[1], -0.03), v[2]]), shoe_c, 'cloth', 0)

    # ---------------- arms (shoulder pivot ±0.27, 1.48, 0) ----------------
    for sx, nm in ((-1, 'n'), (1, 'p')):
        ax = sx * 0.27 * thin * bulk
        up = empty(f'upperarm_{nm}', root)
        make_obj(f'shoulder_{nm}', up, sphere((ax, 1.48, 0), (0.09 * bulk, 0.08 * bulk, 0.085 * bulk), 14, 10), top if outfit != 'bare' else skin, 'cloth' if outfit != 'bare' else 'skin', 1, seed=seed)
        make_obj(f'upper_{nm}_s', up, limb((ax, 1.48, 0), 0.31, 0.065 * bulk, 0.052 * bulk, 14, bulge=0.012 * bulk), skin, 'skin', 1, lumpy=0.006, seed=seed)
        if outfit != 'bare':
            make_obj(f'sleeve_{nm}', up, limb((ax, 1.5, 0), 0.2 if sx > 0 else 0.3, 0.078, 0.068, 14), top, 'cloth', 1, holes=0.15, seed=seed + 20 + sx)
        fore = empty(f'forearm_{nm}', root)
        ey = 1.48 - 0.3
        make_obj(f'fore_{nm}_s', fore, limb((ax, ey, 0), 0.28, 0.052 * bulk, 0.04 * bulk, 14, bulge=0.008), skin, 'skin', 1, lumpy=0.006, seed=seed)
        if outfit != 'bare' and sx < 0:
            make_obj(f'cuff_{nm}', fore, limb((ax, ey + 0.01, 0), 0.12, 0.062, 0.058, 14), top, 'cloth', 1, holes=0.2, seed=seed + 30)
        if ztype == 'runner':
            for k, y in enumerate((ey - 0.08, ey - 0.16)):
                make_obj(f'bandage_{nm}{k}', fore, limb((ax, y + 0.02, 0), 0.04, 0.056, 0.054, 12), cloth_fn('#d6d3c4', seed + 40, -9), 'cloth', 0)
        hy = ey - 0.3
        make_obj(f'palm_{nm}', fore, sphere((ax, hy, 0.005), (0.045 * bulk, 0.055 * bulk, 0.025 * bulk), 12, 8), skin, 'skin', 0)
        for k, fx in enumerate((-0.03, -0.01, 0.01, 0.03)):
            curl = rnd.uniform(0.25, 0.6)
            pts = []
            for i in range(5):
                t = i / 4
                pts.append((ax + fx * bulk, hy - 0.05 * bulk - t * 0.075 * bulk * math.cos(curl * t), 0.005 + t * 0.06 * math.sin(curl * t) * bulk, 0.011 * bulk * (1 - t * 0.3), 0.011 * bulk * (1 - t * 0.3)))
            make_obj(f'finger_{nm}{k}', fore, lathe(pts, 8), lambda p, n: mix(skin(p, n), hexc('#3a3020'), 0.6) if p[1] < hy - 0.11 * bulk else skin(p, n), 'skin', 0)
        make_obj(f'thumb_{nm}', fore, limb((ax - sx * 0.04 * bulk, hy - 0.01, 0.02), 0.06, 0.012 * bulk, 0.01 * bulk, 8), skin, 'skin', 0)

    # ---------------- head (pivot 0, 1.74, 0.03) ----------------
    head = empty('head', root)
    hc = (0, 1.76, 0.03)
    def head_deform(v):
        x, y, z = v
        for ex in (-0.058, 0.058):                       # sunken eye sockets
            d = math.sqrt((x - ex) ** 2 + (y - 0.015) ** 2 * 1.6)
            if z > 0.05 and d < 0.055: z -= (0.055 - d) * 0.6
        if z > 0.05 and 0.04 < y < 0.075: z += 0.012     # brow ridge
        if z > 0.02 and y < -0.02: x *= 0.92             # narrower lower face
        if y < -0.06: z *= 0.96
        for ex in (-0.075, 0.075):                       # cheekbones
            d = math.sqrt((x - ex) ** 2 + (y + 0.03) ** 2)
            if z > 0.05 and d < 0.04: z += (0.04 - d) * 0.3
        return [x, y, z]
    make_obj('skull', head, sphere(hc, (0.15, 0.17, 0.158), 28, 20, deform=head_deform), lambda p, n: (
        mix(skin(p, n), hexc('#2a1030'), 0.7) if (p[2] > hc[2] + 0.09 and min(math.hypot(p[0] - ex, p[1] - hc[1] - 0.015) for ex in (-0.058, 0.058)) < 0.05) else skin(p, n)),
        'skin', 1, lumpy=0.006, seed=seed + 50)
    for ex in (-0.058, 0.058):
        make_obj(f'eye{ex}', head, sphere((hc[0] + ex, hc[1] + 0.015, hc[2] + 0.118), (0.026,) * 3, 12, 8), solid('#ffe680' if ztype != 'spitter' else '#c8ff5a'), 'glow', 0)
        make_obj(f'pupil{ex}', head, sphere((hc[0] + ex, hc[1] + 0.015, hc[2] + 0.14), (0.008,) * 3, 8, 6), solid('#7a3a00'), 'glow', 0)
    make_obj('nose', head, sphere((hc[0], hc[1] - 0.02, hc[2] + 0.15), (0.02, 0.03, 0.025), 10, 8), skin, 'skin', 0)
    for sx in (-1, 1):
        make_obj(f'ear{sx}', head, sphere((hc[0] + sx * 0.148, hc[1], hc[2]), (0.015, 0.035, 0.025), 10, 8), skin, 'skin', 0)
    make_obj('mouth', head, box((hc[0], hc[1] - 0.085, hc[2] + 0.128), (0.12, 0.05, 0.02)), solid('#1a0505'), 'skin', 0)
    for k in range(6):
        th = 0.016 + rnd.random() * 0.016
        make_obj(f'tooth{k}', head, box((hc[0] - 0.05 + k * 0.02, hc[1] - 0.064 - th / 2, hc[2] + 0.136), (0.015, th, 0.012)), solid(rnd.choice(['#e6dcb0', '#d4c48a', '#c9b779'])), 'skin', 0)
    if outfit == 'worker':
        make_obj('hardhat', head, sphere((hc[0], hc[1] + 0.07, hc[2]), (0.172, 0.13, 0.18), 20, 12, deform=lambda v: [v[0], max(v[1], 0), v[2]]), cloth_fn('#facc15', seed + 60, -9), 'skin', 1)
        make_obj('brim', head, lathe([(hc[0], hc[1] + 0.08, hc[2] + 0.02, 0.2, 0.22), (hc[0], hc[1] + 0.065, hc[2] + 0.02, 0.2, 0.22)], 24), cloth_fn('#eab308', seed + 61, -9), 'skin', 0)
    elif outfit == 'guard':
        make_obj('cap', head, lathe([(hc[0], hc[1] + 0.2, hc[2] - 0.01, 0.16, 0.165), (hc[0], hc[1] + 0.12, hc[2], 0.16, 0.165), (hc[0], hc[1] + 0.09, hc[2], 0.157, 0.162)], 20), cloth_fn('#1b2440', seed + 62), 'cloth', 1)
        make_obj('visor', head, box((hc[0], hc[1] + 0.1, hc[2] + 0.19), (0.2, 0.012, 0.1)), solid('#10162a'), 'skin', 0)
        make_obj('capbadge', head, box((hc[0], hc[1] + 0.15, hc[2] + 0.167), (0.05, 0.035, 0.01)), solid('#d4a23a'), 'skin', 0)
    elif outfit == 'suit':
        for ex in (-0.058, 0.058):
            make_obj(f'lens{ex}', head, lathe([(hc[0] + ex, hc[1] + 0.015, hc[2] + 0.158, 0.038, 0.003), (hc[0] + ex, hc[1] + 0.012, hc[2] + 0.158, 0.038, 0.003)], 16), solid('#111111'), 'skin', 0)
        make_obj('bridge', head, box((hc[0], hc[1] + 0.02, hc[2] + 0.158), (0.04, 0.006, 0.006)), solid('#111111'), 'skin', 0)
    elif outfit == 'hoodie':
        def hood_def(v):
            x, y, z = v
            if z > 0.06 and y < 0.12 and abs(x) < 0.15: z = 0.06 + (z - 0.06) * 0.15
            return [x, y, z]
        make_obj('hood', head, sphere((hc[0], hc[1] + 0.02, hc[2] - 0.03), (0.19, 0.21, 0.2), 22, 14, deform=hood_def), top, 'cloth', 1, holes=0.05, seed=seed + 63)
    if ztype != 'brute' and outfit not in ('worker', 'guard', 'hoodie'):
        hair_c = rnd.choice(['#1a1a14', '#3b2a1a', '#6b6b6b'])
        for k in range(9):
            a = rnd.random() * math.tau; r = rnd.uniform(0.03, 0.1)
            make_obj(f'hair{k}', head, sphere((hc[0] + math.cos(a) * r, hc[1] + 0.14 - r * 0.25, hc[2] + math.sin(a) * r - 0.03), (0.06, 0.03, 0.06), 10, 6), cloth_fn(hair_c, seed + k), 'cloth', 0)

    jaw = empty('jaw', root)
    jc = (hc[0], hc[1] - 0.08, hc[2] + 0.02)
    make_obj('jawbone', jaw, sphere((jc[0], jc[1] - 0.035, jc[2] + 0.05), (0.095, 0.04, 0.085), 16, 10), skin, 'skin', 1, seed=seed + 70)
    for k in range(5):
        if rnd.random() < 0.25: continue
        th = 0.012 + rnd.random() * 0.014
        make_obj(f'ltooth{k}', jaw, box((jc[0] - 0.04 + k * 0.02, jc[1] - 0.004 + th / 2, jc[2] + 0.11), (0.015, th, 0.012)), solid('#d8cc98'), 'skin', 0)

    # export
    OUT.mkdir(exist_ok=True)
    fname = OUT / f'{ztype}_{outfit}.glb'
    bpy.ops.export_scene.gltf(filepath=str(fname), export_format='GLB', export_apply=True,
                              export_vertex_color='ACTIVE', export_yup=True)
    print('wrote', fname)


VARIANTS = [
    ('walker', 'suit', '#2b2f36', '#1f2228', 101),
    ('walker', 'guard', '#24345e', '#1b2440', 102),
    ('walker', 'worker', '#5b6470', '#3a4a63', 103),
    ('walker', 'casual_red', '#7f1d1d', '#2f4a6e', 104),
    ('walker', 'casual_green', '#166534', '#2f4a6e', 105),
    ('runner', 'hoodie', '#3f3f46', '#27272a', 106),
    ('spitter', 'sick', '#41522a', '#2b2a24', 107),
    ('brute', 'bare', None, '#3b2f25', 108),
]

if __name__ == '__main__':
    for (zt, variant, tp, bt, sd) in VARIANTS:
        kind = 'casual' if variant.startswith('casual') else variant
        build(zt, kind, tp, bt, sd)
        if kind != variant:                      # casual_red / casual_green
            src, dst = OUT / f'{zt}_{kind}.glb', OUT / f'{zt}_{variant}.glb'
            if dst.exists(): dst.unlink()
            src.rename(dst)
    print('done')
