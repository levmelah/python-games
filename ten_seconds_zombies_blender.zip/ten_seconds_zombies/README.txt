TEN SECONDS: ZOMBIES (Python + Blender)

1) pip install ursina
2) python ten_seconds_zombies.py
   (optional lighting & shadows: python ten_seconds_zombies.py --shadows)

zombie_models/            the zombie models built in Blender (.glb), loaded by the game
make_zombies_blender.py   the Blender script that builds them. To rebuild/change them:
                          blender --background --python make_zombies_blender.py
