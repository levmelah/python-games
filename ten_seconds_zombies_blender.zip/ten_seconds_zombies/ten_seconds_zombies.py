"""
TEN SECONDS: ZOMBIES  -  Python version
=======================================
Zombies are attacking the bank. Protect the vault (and yourself).
You can freeze time for up to 10 seconds.

How to run:
    pip install ursina
    python ten_seconds_zombies.py

Zombie models made in Blender:
    put the folder  zombie_models  (made by make_zombies_blender.py) next to this file.
    Without it, the game uses simple box zombies.
    (optional lighting & shadows:  python ten_seconds_zombies.py --shadows)

Controls:
    Mouse ............ aim        Left click (hold) ... shoot
    Q / Right click .. freeze time / release
    WASD ............. move       Shift ............... sprint
    Space ............ jump       R ................... reload
    Esc .............. pause
"""
import math
import sys
import random
import struct
import wave
from pathlib import Path

from ursina import *
from ursina.shaders import lit_with_shadows_shader
from PIL import Image, ImageDraw, ImageFilter
from panda3d.core import Filename

app = Ursina(title='Ten Seconds: Zombies', borderless=False, development_mode=False)
window.color = color.hex('#070a07')
try:
    window.fps_counter.enabled = False
    window.exit_button.visible = False
    window.cog_button.enabled = False
except Exception:
    pass
# Optional real-time lighting & shadows:  python ten_seconds_zombies.py --shadows
# (looks nicer on a good graphics card; if it crashes, just run without it)
SIMPLE_GFX = '--shadows' not in sys.argv
if not SIMPLE_GFX:
    Entity.default_shader = lit_with_shadows_shader
scene.fog_color = color.hex('#0a0f09')
scene.fog_density = (18, 60)
camera.fov = 78


def C(hexstr, a=1.0):
    c = color.hex(hexstr)
    return Color(c[0], c[1], c[2], a)


# ======================================================================
# sounds (generated once into a folder next to this script)
# ======================================================================
SND_DIR = Path(__file__).resolve().parent / 'ten_seconds_sounds'
MODEL_DIR = Path(__file__).resolve().parent / 'zombie_models'   # made by make_zombies_blender.py
SR = 22050


def _write_wav(name, samples):
    SND_DIR.mkdir(exist_ok=True)
    with wave.open(str(SND_DIR / f'{name}.wav'), 'w') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes(b''.join(struct.pack('<h', int(max(-1, min(1, s)) * 30000)) for s in samples))


def _synth(dur, f1, f2, wave_type='sine', noise=0.0, vol=0.6, lowpass=1.0):
    n = int(SR * dur); out = []; ph = 0.0; last = 0.0
    for i in range(n):
        t = i / n
        f = f1 * (f2 / f1) ** t
        ph += f / SR
        if wave_type == 'sine': v = math.sin(ph * 2 * math.pi)
        elif wave_type == 'square': v = 1.0 if (ph % 1) < 0.5 else -1.0
        else: v = 2 * (ph % 1) - 1
        v = v * (1 - noise) + (random.random() * 2 - 1) * noise
        last = last + (v - last) * lowpass
        out.append(last * vol * (1 - t) ** 2)
    return out


def make_sounds():
    if (SND_DIR / 'groan.wav').exists():
        return
    random.seed(3)
    _write_wav('shot', _synth(0.14, 300, 60, 'square', noise=0.8, vol=0.5, lowpass=0.5))
    _write_wav('boom', _synth(1.0, 90, 25, 'sine', noise=0.7, vol=0.9, lowpass=0.08))
    _write_wav('hit', _synth(0.05, 1200, 900, 'square', vol=0.25))
    _write_wav('head', _synth(0.12, 1800, 2600, 'sine', vol=0.4))
    _write_wav('kill', _synth(0.22, 300, 70, 'square', noise=0.3, vol=0.4))
    _write_wav('hurt', _synth(0.25, 160, 60, 'saw', vol=0.45))
    _write_wav('freeze', _synth(0.9, 900, 40, 'sine', vol=0.6))
    _write_wav('release', _synth(0.6, 40, 380, 'sine', noise=0.5, vol=0.6, lowpass=0.2))
    _write_wav('cash', _synth(0.12, 988, 1319, 'square', vol=0.2))
    _write_wav('wave', _synth(0.5, 392, 784, 'sine', vol=0.4))
    _write_wav('acid', _synth(0.3, 300, 120, 'saw', noise=0.4, vol=0.3, lowpass=0.3))
    _write_wav('groan', _synth(0.8, 95, 60, 'saw', noise=0.1, vol=0.35, lowpass=0.15))
    _write_wav('reload', _synth(0.15, 500, 900, 'square', vol=0.2))


SOUNDS = {}
try:
    make_sounds()
    for nm in ['shot', 'boom', 'hit', 'head', 'kill', 'hurt', 'freeze', 'release', 'cash', 'wave', 'acid', 'groan', 'reload']:
        SOUNDS[nm] = Audio(f'ten_seconds_sounds/{nm}.wav', autoplay=False)
except Exception as ex:
    print('sound disabled:', ex)


def snd(name, vol=1.0, pitch=None):
    a = SOUNDS.get(name)
    if not a:
        return
    try:
        a.volume = vol
        a.pitch = pitch if pitch else random.uniform(0.92, 1.08)
        a.play()
    except Exception:
        pass


# ======================================================================
# textures
# ======================================================================
def tex_from(img):
    return Texture(img)


def make_marble():
    img = Image.new('RGB', (512, 512)); d = ImageDraw.Draw(img); s = 256
    for i in range(2):
        for j in range(2):
            dark = (i + j) % 2
            d.rectangle([i * s, j * s, i * s + s, j * s + s], fill=(42, 39, 36) if dark else (216, 209, 196))
            for _ in range(14):
                x = i * s + random.random() * s; y = j * s
                pts = [(x, y)]
                for _ in range(8):
                    x += (random.random() - 0.5) * 50; y += s / 8
                    pts.append((max(i * s, min(i * s + s, x)), y))
                c = (190, 160, 110) if dark else (110, 100, 90)
                d.line(pts, fill=c, width=1)
            d.rectangle([i * s, j * s, i * s + s - 1, j * s + s - 1], outline=(0, 0, 0), width=2)
    return tex_from(img)


def make_wood():
    img = Image.new('RGB', (256, 512), (59, 36, 22)); d = ImageDraw.Draw(img)
    for _ in range(70):
        x = random.random() * 256
        d.line([(x, 0), (x + random.uniform(-8, 8), 512)], fill=(30 + int(random.random() * 30), 18, 8), width=random.randint(1, 3))
    d.rectangle([0, 240, 256, 250], fill=(176, 138, 62))
    d.rectangle([14, 14, 242, 226], outline=(25, 15, 8), width=4)
    d.rectangle([14, 266, 242, 498], outline=(25, 15, 8), width=4)
    return tex_from(img)


def make_grime(base, tears=0, veins=False, seed=0):
    rnd = random.Random(seed)
    img = Image.new('RGB', (128, 128), base); d = ImageDraw.Draw(img)
    for _ in range(900):
        v = rnd.random()
        x, y = rnd.random() * 128, rnd.random() * 128
        c = tuple(max(0, min(255, int(ch * (0.8 + v * 0.35)))) for ch in base)
        d.rectangle([x, y, x + 2, y + 2], fill=c)
    for _ in range(8):
        x, y, r = rnd.random() * 128, rnd.random() * 128, 6 + rnd.random() * 16
        c = tuple(int(ch * 0.6) for ch in base)
        d.ellipse([x - r, y - r, x + r, y + r], fill=c)
    if veins:
        for _ in range(12):
            x, y = rnd.random() * 128, rnd.random() * 128; pts = [(x, y)]
            for _ in range(5):
                x += (rnd.random() - 0.5) * 20; y += (rnd.random() - 0.5) * 20; pts.append((x, y))
            d.line(pts, fill=(int(base[0] * 0.55), int(base[1] * 0.4), int(base[2] * 0.7)), width=1)
    for _ in range(tears):
        x, y = rnd.random() * 128, rnd.random() * 128
        d.polygon([(x + (rnd.random() - 0.3) * 22, y + (rnd.random() - 0.3) * 22) for _ in range(6)], fill=(125, 143, 90))
    img = img.filter(ImageFilter.GaussianBlur(0.6))
    return tex_from(img)


random.seed(11)
MARBLE = make_marble()
WOOD = make_wood()
SKIN_TEX = make_grime((220, 224, 205), veins=True, seed=1)
CLOTH_TEX = {}


def cloth_tex(hexcol):
    if hexcol not in CLOTH_TEX:
        c = color.hex(hexcol)
        CLOTH_TEX[hexcol] = make_grime((int(c[0] * 255), int(c[1] * 255), int(c[2] * 255)), tears=4, seed=hash(hexcol) % 999)
    return CLOTH_TEX[hexcol]


# ======================================================================
# arena
# ======================================================================
AX, AZ, WH = 20, 15, 8
COLS = []    # (x, z, r)
BOXES = []   # (x0, x1, z0, z1, h)

Entity(model='plane', scale=(AX * 2, 1, AZ * 2), texture=MARBLE, texture_scale=(10, 7.5))
Entity(model='plane', scale=(AX * 2, 1, AZ * 2), y=WH, rotation_x=180, color=C('#14110e'))
for (x, z, w, d) in [(0, -AZ - 0.5, AX * 2 + 2, 1), (0, AZ + 0.5, AX * 2 + 2, 1), (-AX - 0.5, 0, 1, AZ * 2), (AX + 0.5, 0, 1, AZ * 2)]:
    Entity(model='cube', position=(x, WH / 2, z), scale=(w, WH, d), texture=WOOD, texture_scale=(max(w, d) / 3, 1))
for z in (-AZ + 0.03, AZ - 0.03):
    Entity(model='cube', position=(0, 2.6, z), scale=(AX * 2, 0.12, 0.05), color=C('#d4a23a'))

for x in (-12, -4, 4, 12):
    for z in (-5.5, 5.5):
        Entity(model=Cylinder(20), position=(x, 0, z), scale=(1.1, WH, 1.1), color=C('#e9e4da'))
        Entity(model='cube', position=(x, 0.2, z), scale=(1.5, 0.4, 1.5), color=C('#e9e4da'))
        Entity(model='cube', position=(x, WH - 0.2, z), scale=(1.5, 0.4, 1.5), color=C('#e9e4da'))
        Entity(model=Cylinder(20), position=(x, 1.55, z), scale=(1.25, 0.12, 1.25), color=C('#d4a23a'))
        COLS.append((x, z, 0.75))


def add_box(x, z, w, d, h, col, top=None):
    Entity(model='cube', position=(x, h / 2, z), scale=(w, h, d), color=C(col))
    if top:
        Entity(model='cube', position=(x, h + 0.04, z), scale=(w + 0.15, 0.08, d + 0.15), color=C(top))
    BOXES.append((x - w / 2, x + w / 2, z - d / 2, z + d / 2, h))


add_box(-6, -10, 5, 1, 1.15, '#2b1a10', '#111111')
add_box(6, -10, 5, 1, 1.15, '#2b1a10', '#111111')
add_box(0, 3.5, 2, 2, 1.2, '#4b5563')
add_box(-15, 9, 2, 2, 1.2, '#4b5563')
add_box(15, -1, 2, 2, 1.2, '#4b5563')
add_box(-8, 11, 3, 1, 1.0, '#4b5563')
add_box(9, 9, 1.4, 1.4, 1.4, '#4b5563')

# vault door (hinged so it can shake)
vault_hinge = Entity(position=(-3, 3.4, -AZ + 0.25))
vault_door = Entity(parent=vault_hinge, x=3)
Entity(parent=vault_door, model=Cylinder(40), rotation_x=90, scale=(6.6, 0.3, 6.6), color=C('#d4a23a'))
Entity(parent=vault_door, model=Cylinder(40), rotation_x=90, scale=(5.6, 0.5, 5.6), z=0.05, color=C('#8a8f98'))
Entity(parent=vault_door, model=Cylinder(24), rotation_x=90, scale=(1, 0.8, 1), z=0.1, color=C('#d4a23a'))
for i in range(3):
    Entity(parent=vault_door, model='cube', scale=(3.2, 0.18, 0.18), z=-0.35, rotation_z=i * 60, color=C('#d4a23a'))

# chandeliers
for (x, z) in [(-10, 0), (10, 0), (0, -8), (0, 8)]:
    Entity(model='sphere', position=(x, WH - 1.2, z), scale=0.8, color=C('#fff3d6'), unlit=True)
    Entity(model='quad', position=(x, WH - 1.2, z), scale=3, billboard=True, texture='radial_gradient', color=C('#ffd29a', 0.35), unlit=True)

SPAWNS = [(-AX + 1.2, 0), (AX - 1.2, 0), (-12, -AZ + 1.2), (12, -AZ + 1.2), (0, AZ - 1.2), (-12, AZ - 1.2), (12, AZ - 1.2)]
door_glow = []
for (x, z) in SPAWNS:
    on_x = abs(x) > AX - 2
    Entity(model='cube', position=(math.copysign(AX - 0.05, x) if on_x else x, 1.6, z if on_x else math.copysign(AZ - 0.05, z)),
           scale=(0.2, 3.2, 2.4) if on_x else (2.4, 3.2, 0.2), color=C('#050505'))
    door_glow.append(Entity(model='quad', billboard=True, position=(x * 0.97, 1.8, z * 0.97), scale=3, texture='radial_gradient', color=C('#ff2a2a', 0), unlit=True))

sun = DirectionalLight(shadow_map_resolution=Vec2(2048, 2048), shadows=not SIMPLE_GFX)
sun.look_at(Vec3(-0.6, -2, -0.4))
AmbientLight(color=Color(0.45, 0.5, 0.45, 1))
try:
    sun.update_bounds(scene)
except Exception:
    pass


# ======================================================================
# collision helpers
# ======================================================================
def push_out(x, z, r, y=None):
    for (cx, cz, cr) in COLS:
        dx, dz = x - cx, z - cz; d = math.hypot(dx, dz); m = cr + r
        if 0.0001 < d < m:
            x, z = cx + dx / d * m, cz + dz / d * m
    for (x0, x1, z0, z1, h) in BOXES:
        if y is not None and y > h + 0.05:
            continue
        px, pz = max(x0, min(x, x1)), max(z0, min(z, z1))
        dx, dz = x - px, z - pz; d = math.hypot(dx, dz)
        if d < r:
            if d > 0.0001:
                x, z = px + dx / d * r, pz + dz / d * r
            else:
                opts = sorted([(x - x0, -1, 0), (x1 - x, 1, 0), (z - z0, 0, -1), (z1 - z, 0, 1)])
                o = opts[0]; x += o[1] * (o[0] + r); z += o[2] * (o[0] + r)
    return max(-AX + r, min(AX - r, x)), max(-AZ + r, min(AZ - r, z))


def blocked(x, y, z):
    if y < 0 or y > WH or abs(x) > AX or abs(z) > AZ:
        return True
    for (cx, cz, cr) in COLS:
        if math.hypot(x - cx, z - cz) < cr - 0.15:
            return True
    for (x0, x1, z0, z1, h) in BOXES:
        if y < h and x0 < x < x1 and z0 < z < z1:
            return True
    return False


def clear_line(a, b):
    d = distance(a, b); n = max(1, int(d / 0.5))
    for i in range(1, n):
        t = i / n
        if blocked(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t, a.z + (b.z - a.z) * t):
            return False
    return True


def floor_under(x, z):
    h = 0
    for (x0, x1, z0, z1, bh) in BOXES:
        if x0 - 0.2 < x < x1 + 0.2 and z0 - 0.2 < z < z1 + 0.2:
            h = max(h, bh)
    return h


# ======================================================================
# zombies
# ======================================================================
ZT = {
    'walker':  dict(hp=90,  speed=1.9, dmg=10, vdmg=15, s=1.0,  skin='#8ea56a', val=100, atk=1.1),
    'runner':  dict(hp=55,  speed=5.2, dmg=8,  vdmg=10, s=0.95, skin='#a9b389', val=150, atk=0.75),
    'spitter': dict(hp=70,  speed=2.3, dmg=10, vdmg=10, s=1.0,  skin='#9cc35a', val=200, atk=1.2),
    'brute':   dict(hp=450, speed=1.5, dmg=25, vdmg=45, s=1.55, skin='#6d8a4f', val=500, atk=1.5),
}
OUTFITS = {
    'suit':   ('#2b2f36', '#1f2228'), 'guard': ('#24345e', '#1b2440'), 'worker': ('#5b6470', '#3a4a63'),
    'casual': (None, '#2f4a6e'), 'hoodie': ('#3f3f46', '#27272a'), 'bare': (None, '#3b2f25'), 'sick': ('#41522a', '#2b2a24'),
}


def part(parent, model, pos, scale, col=None, tex=None, unlit=False, rot=(0, 0, 0)):
    e = Entity(parent=parent, model=model, position=pos, scale=scale, rotation=rot, unlit=unlit)
    if tex is not None:
        e.texture = tex
    if col is not None:
        e.color = col
    return e


class Zombie:
    def __init__(self, ztype, rng=random, wave_n=1):
        T = ZT[ztype]; self.T = T; self.type = ztype; self.s = T['s']
        outfit = {'runner': 'hoodie', 'brute': 'bare', 'spitter': 'sick'}.get(ztype) or rng.choice(['suit', 'guard', 'worker', 'casual'])
        top_hex, bot_hex = OUTFITS[outfit]
        top_hex = top_hex or rng.choice(['#7f1d1d', '#1e40af', '#a16207', '#166534', '#6b21a8'])
        skin_c = C(T['skin'])
        top_t = SKIN_TEX if outfit == 'bare' else cloth_tex(top_hex)
        top_c = skin_c if outfit == 'bare' else color.white
        bot_t = cloth_tex(bot_hex)
        dark = C('#1a0f0f')
        thin = 0.85 if ztype == 'runner' else 1.0
        bulk = 1.35 if ztype == 'brute' else 1.0
        eye_c = C('#b8ff5a') if ztype == 'spitter' else C('#ffd84a')

        self.root = Entity()
        self.model = Entity(parent=self.root, scale=self.s)
        if not (MODEL_DIR.exists() and self._build_from_blender(ztype, outfit, rng, thin, bulk, eye_c)):
            self._build_boxes(ztype, outfit, rng, thin, bulk, eye_c, skin_c, top_t, top_c, bot_t, dark)
        self._init_state(ztype, rng, wave_n)

    # ---------- models made in Blender (zombie_models/*.glb) ----------
    def _build_from_blender(self, ztype, outfit, rng, thin, bulk, eye_c):
        variant = {'walker': rng.choice(['suit', 'guard', 'worker', 'casual_red', 'casual_green']),
                   'runner': 'hoodie', 'spitter': 'sick', 'brute': 'bare'}[ztype]
        if ztype == 'walker' and outfit in ('suit', 'guard', 'worker'):
            variant = outfit
        path = MODEL_DIR / f'{ztype}_{variant}.glb'
        if not path.exists():
            return False
        try:
            np = application.base.loader.loadModel(Filename.fromOsSpecific(str(path)))
        except Exception as ex:
            print('could not load', path, ex)
            return False
        m = self.model
        body = Entity(parent=m, y=0.9)
        hips = [Entity(parent=m, position=(sx * 0.11 * bulk, 0.9, 0)) for sx in (-1, 1)]
        knees = [Entity(parent=h, y=-0.46) for h in hips]
        shoulders = [Entity(parent=body, position=(sx * 0.27 * thin * bulk, 0.58, 0)) for sx in (-1, 1)]
        elbows = [Entity(parent=sh, y=-0.3) for sh in shoulders]
        head = Entity(parent=body, position=(0, 0.86, 0.03))
        jaw = Entity(parent=head, position=(0, -0.08, 0.02))
        np.reparentTo(m)
        joints = {'body': body, 'thigh_n': hips[0], 'thigh_p': hips[1], 'shin_n': knees[0], 'shin_p': knees[1],
                  'upperarm_n': shoulders[0], 'upperarm_p': shoulders[1], 'forearm_n': elbows[0], 'forearm_p': elbows[1],
                  'head': head, 'jaw': jaw}
        for name, joint in joints.items():
            n = np.find('**/' + name)
            if not n.isEmpty():
                n.wrtReparentTo(joint)
        np.removeNode()
        # base pose
        body.rotation_x = 26 if ztype == 'runner' else 17
        body.rotation_z = rng.uniform(-5, 5)
        for sx, sh in zip((-1, 1), shoulders):
            sh.rotation = Vec3(-95, 0, sx * 7)
        self.body, self.hips, self.knees, self.shoulders, self.elbows, self.head, self.jaw = body, hips, knees, shoulders, elbows, head, jaw
        self.glows = []
        for ex in (-0.058, 0.058):
            g = Entity(parent=head, model='quad', texture='radial_gradient', position=(ex, 0.015, 0.15), scale=0.12,
                       color=Color(eye_c[0], eye_c[1], eye_c[2], 0.55), unlit=True, billboard=True)
            self.glows.append(g)
        self.shreds = []
        return True

    # ---------- simple box models (used if the Blender models are missing) ----------
    def _build_boxes(self, ztype, outfit, rng, thin, bulk, eye_c, skin_c, top_t, top_c, bot_t, dark):
        # legs
        self.hips, self.knees = [], []
        for sx in (-0.11, 0.11):
            hip = Entity(parent=self.model, position=(sx * bulk, 0.9, 0))
            part(hip, 'cube', (0, -0.23, 0), (0.16 * thin * bulk, 0.46, 0.17 * thin * bulk), tex=bot_t)
            knee = Entity(parent=hip, y=-0.46)
            part(knee, 'cube', (0, -0.21, 0), (0.13 * thin * bulk, 0.42, 0.14 * thin * bulk), col=skin_c if ztype == 'brute' else None, tex=SKIN_TEX if ztype == 'brute' else bot_t)
            part(knee, 'cube', (0, -0.44, 0.05), (0.13 * bulk, 0.08, 0.26), col=skin_c if ztype == 'brute' else dark, tex=SKIN_TEX if ztype == 'brute' else None)
            self.hips.append(hip); self.knees.append(knee)
        # body
        self.body = Entity(parent=self.model, y=0.9, rotation_x=26 if ztype == 'runner' else 17, rotation_z=rng.uniform(-5, 5))
        part(self.body, 'cube', (0, 0.03, 0), (0.3 * bulk, 0.16, 0.19 * bulk), tex=bot_t)
        part(self.body, 'cube', (0, 0.36, 0), (0.48 * thin * bulk, 0.6, 0.3 * thin * bulk), col=top_c, tex=top_t)
        for sx in (-1, 1):
            part(self.body, 'sphere', (sx * 0.25 * thin * bulk, 0.6, 0), 0.19 * bulk, col=top_c, tex=top_t)
        part(self.body, 'cube', (0, 0.71, 0.02), (0.12, 0.14, 0.12), col=skin_c, tex=SKIN_TEX)
        fz = 0.15 * thin * bulk + 0.006
        if outfit == 'suit':
            part(self.body, 'cube', (0, 0.46, fz), (0.12, 0.3, 0.01), col=C('#e5e7eb'))
            part(self.body, 'cube', (0, 0.44, fz + 0.008), (0.045, 0.28, 0.012), col=C('#991b1b'), rot=(0, 0, 7))
        elif outfit == 'guard':
            part(self.body, 'cube', (0.1, 0.5, fz), (0.06, 0.07, 0.012), col=C('#d4a23a'))
            part(self.body, 'cube', (0, 0.09, 0), (0.44, 0.06, 0.32), col=C('#111111'))
        elif outfit == 'worker':
            part(self.body, 'cube', (0, 0.38, 0), (0.5, 0.5, 0.32), col=C('#f97316'))
            for y in (0.28, 0.48):
                part(self.body, 'cube', (0, y, 0), (0.51, 0.04, 0.33), col=C('#e5e7eb'), unlit=True)
        elif outfit == 'bare':
            for x in (-0.08, 0.08):
                part(self.body, 'sphere', (x, 0.42, fz - 0.03), (0.18, 0.12, 0.08), col=skin_c, tex=SKIN_TEX)
            for k in range(3):
                part(self.body, 'cube', (0.05, 0.22 + k * 0.05, fz + 0.005), (0.14, 0.02, 0.02), col=C('#5b2a2a'), rot=(0, 0, 28))
        if ztype == 'spitter':
            part(self.body, 'sphere', (0, 0.22, 0.12), (0.54, 0.5, 0.48), col=C('#9dff3a'), unlit=True)
            for _ in range(7):
                a = rng.uniform(-1.4, 1.4)
                part(self.body, 'sphere', (math.sin(a) * 0.25, 0.22 + rng.uniform(-0.12, 0.12), 0.12 + math.cos(a) * 0.24), rng.uniform(0.05, 0.1), col=C('#e3ff8a'), unlit=True)
        # arms
        self.shoulders, self.elbows = [], []
        for sx in (-1, 1):
            sh = Entity(parent=self.body, position=(sx * 0.29 * thin * bulk, 0.58, 0), rotation=(-95, 0, sx * 7))
            sleeve_bare = outfit == 'bare'
            part(sh, 'cube', (0, -0.15, 0), (0.12 * bulk, 0.3, 0.12 * bulk), col=skin_c if sleeve_bare else top_c, tex=SKIN_TEX if sleeve_bare else top_t)
            el = Entity(parent=sh, y=-0.3)
            torn = sx > 0 or sleeve_bare
            part(el, 'cube', (0, -0.14, 0), (0.1 * bulk, 0.28, 0.1 * bulk), col=skin_c if torn else top_c, tex=SKIN_TEX if torn else top_t)
            part(el, 'cube', (0, -0.32, 0), (0.085 * bulk, 0.1 * bulk, 0.04 * bulk), col=skin_c, tex=SKIN_TEX)
            for fx in (-0.03, -0.01, 0.01, 0.03):
                part(el, 'cube', (fx * bulk, -0.39, 0.012), (0.016 * bulk, 0.07 * bulk, 0.016 * bulk), col=skin_c, rot=(rng.uniform(20, 45), 0, 0))
            if ztype == 'runner':
                for y in (-0.08, -0.16):
                    part(el, 'cube', (0, y, 0), (0.115, 0.035, 0.115), col=C('#d6d3c4'))
            self.shoulders.append(sh); self.elbows.append(el)
        # head
        self.head = Entity(parent=self.body, position=(0, 0.86, 0.05))
        part(self.head, 'sphere', (0, 0, 0), (0.31, 0.35, 0.33), col=skin_c, tex=SKIN_TEX)
        part(self.head, 'cube', (0, 0.06, 0.13), (0.25, 0.04, 0.06), col=skin_c, tex=SKIN_TEX)
        for ex in (-0.058, 0.058):
            part(self.head, 'sphere', (ex, 0.015, 0.125), (0.09, 0.09, 0.045), col=dark)
            part(self.head, 'sphere', (ex, 0.015, 0.142), 0.05, col=eye_c, unlit=True)
        self.glows = [part(self.head, 'quad', (ex, 0.015, 0.16), 0.13, col=Color(eye_c[0], eye_c[1], eye_c[2], 0.6), tex='radial_gradient', unlit=True) for ex in (-0.058, 0.058)]
        for g in self.glows:
            g.billboard = True
        part(self.head, 'cube', (0, -0.02, 0.16), (0.03, 0.05, 0.04), col=skin_c)
        for ex in (-1, 1):
            part(self.head, 'cube', (ex * 0.155, 0, 0), (0.03, 0.06, 0.04), col=skin_c)
        part(self.head, 'cube', (0, -0.085, 0.14), (0.13, 0.05, 0.02), col=dark)
        tooth = C('#e6dcb0')
        for k in range(6):
            th = 0.018 + rng.random() * 0.016
            part(self.head, 'cube', (-0.05 + k * 0.02, -0.062 - th / 2, 0.148), (0.016, th, 0.014), col=tooth)
        self.jaw = Entity(parent=self.head, position=(0, -0.08, 0.02))
        part(self.jaw, 'cube', (0, -0.035, 0.06), (0.18, 0.05, 0.15), col=skin_c, tex=SKIN_TEX)
        for k in range(5):
            if rng.random() < 0.2: continue
            th = 0.014 + rng.random() * 0.014
            part(self.jaw, 'cube', (-0.04 + k * 0.02, -0.004 + th / 2, 0.128), (0.016, th, 0.014), col=tooth)
        # hats / hair
        if outfit == 'worker':
            part(self.head, 'sphere', (0, 0.1, 0), (0.36, 0.22, 0.36), col=C('#facc15'), rot=(rng.uniform(-15, 5), 0, rng.uniform(-12, 12)))
            part(self.head, Cylinder(24), (0, 0.06, 0.01), (0.42, 0.015, 0.42), col=C('#facc15'))
        elif outfit == 'guard':
            part(self.head, Cylinder(20), (0, 0.11, 0), (0.34, 0.08, 0.34), col=C('#1b2440'), rot=(0, 0, rng.uniform(-8, 8)))
            part(self.head, 'cube', (0, 0.115, 0.16), (0.2, 0.012, 0.1), col=C('#1b2440'), rot=(14, 0, 0))
        elif outfit == 'suit':
            for ex in (-0.058, 0.058):
                part(self.head, 'cube', (ex, 0.015, 0.165), (0.08, 0.06, 0.004), col=Color(0.1, 0.1, 0.1, 0.35))
            part(self.head, 'cube', (0, 0.02, 0.167), (0.04, 0.006, 0.006), col=C('#111111'))
        elif outfit == 'hoodie':
            part(self.head, 'sphere', (0, 0.03, -0.05), (0.4, 0.42, 0.38), col=color.white, tex=top_t)
        if ztype != 'brute' and outfit not in ('hoodie', 'worker', 'guard'):
            hair_c = C(rng.choice(['#1a1a14', '#3b2a1a', '#6b6b6b']))
            for _ in range(5):
                a = rng.random() * math.tau
                part(self.head, 'sphere', (math.cos(a) * 0.08, 0.12 + rng.random() * 0.03, math.sin(a) * 0.08 - 0.02), (0.18, 0.07, 0.18), col=hair_c)
        # cloth shreds
        self.shreds = []
        if outfit != 'bare':
            for k in range(5):
                a = -1.2 + k * 0.6
                hang = Entity(parent=self.body, position=(math.sin(a) * 0.2 * thin * bulk, 0.07, math.cos(a) * 0.14 * thin * bulk), rotation_y=math.degrees(a))
                ln = 0.08 + rng.random() * 0.12
                part(hang, 'cube', (0, -ln / 2, 0), (0.06, ln, 0.008), col=top_c, tex=top_t)
                self.shreds.append(hang)

    def _init_state(self, ztype, rng, wave_n):
        T = self.T
        self.hp = T['hp']; self.dead = False; self.landed = False; self.gone = False
        self.speed = T['speed'] * (1 + min(0.5, wave_n * 0.03)) * rng.uniform(0.85, 1.15)
        self.target = 'player' if ztype == 'spitter' else ('vault' if rng.random() < 0.45 else 'player')
        self.walk = rng.random() * 6; self.atk_t = 0.5; self.swing = 0; self.spit_t = rng.uniform(1.5, 3.5)
        self.vel = Vec3(0, 0, 0); self.spin = Vec3(0, 0, 0); self.dead_t = 0; self.flash_t = 0
        self.last = Vec3(0, 0, 0); self.stuck = 0; self.side = rng.choice([-1, 1]); self.limp = rng.uniform(0.55, 1.0)

    @property
    def pos(self):
        return self.root.position

    def head_pos(self):
        return self.head.world_position

    def animate(self, dt, moving, t):
        amp = 48 if self.type == 'runner' else 29
        s0, s1 = math.sin(self.walk), -math.sin(self.walk)
        self.hips[0].rotation_x = s0 * amp
        self.hips[1].rotation_x = s1 * amp * self.limp
        self.knees[0].rotation_x = max(0, s0) * amp * 1.5
        self.knees[1].rotation_x = max(0, s1) * amp * 1.5 * self.limp + (1 - self.limp) * 14
        self.model.y = abs(math.cos(self.walk)) * 0.04 * (1 if moving else 0)
        if self.swing > 0:
            self.swing -= dt
        sw = math.sin((0.35 - self.swing) / 0.35 * math.pi) if self.swing > 0 else 0
        reach = 0.6 if self.type == 'spitter' else 1.0
        self.shoulders[0].rotation_x = (-95 + math.sin(self.walk * 0.5) * 8 - sw * 40) * reach
        self.shoulders[1].rotation_x = (-90 - math.sin(self.walk * 0.5 + 1) * 8 - sw * 40) * reach
        self.elbows[0].rotation_x = -14 - max(0, math.sin(t * 3 + self.walk)) * 14 + sw * 22
        self.elbows[1].rotation_x = -20 - max(0, math.sin(t * 3.3 + self.walk + 2)) * 14 + sw * 22
        self.head.rotation_z = math.sin(self.walk * 0.3) * 10 + 4
        self.head.rotation_x = math.sin(t * 1.7 + self.walk) * 5 - 6
        self.jaw.rotation_x = 12 + abs(math.sin(t * 5 + self.walk)) * 14 + sw * 20
        for k, h in enumerate(self.shreds):
            h.rotation_x = 8 + math.sin(self.walk * 1.5 + k) * 14

    def destroy(self):
        destroy(self.root)


# ======================================================================
# viewmodel gun + HUD
# ======================================================================
gun = Entity(parent=camera, position=(0.24, -0.22, 0.5))
gdark = C('#1b1f27')
Entity(parent=gun, model='cube', scale=(0.09, 0.12, 0.42), color=gdark)
Entity(parent=gun, model='cube', scale=(0.04, 0.04, 0.3), position=(0, 0.02, 0.33), color=gdark)
Entity(parent=gun, model='cube', scale=(0.07, 0.16, 0.08), position=(0, -0.12, -0.1), rotation_x=-14, color=gdark)
Entity(parent=gun, model='cube', scale=(0.095, 0.015, 0.3), position=(0, 0.035, 0.02), color=C('#38bdf8'), unlit=True)
muzzle = Entity(parent=gun, model='quad', texture='radial_gradient', position=(0, 0.02, 0.55), scale=0.35, color=C('#9ae6ff', 0), unlit=True)

UI = camera.ui
AR = window.aspect_ratio


def bar(y, col):
    bg = Entity(parent=UI, model='quad', color=Color(0, 0, 0, 0.55), origin=(0.5, 0), position=(AR / 2 - 0.04, y), scale=(0.42, 0.022))
    fg = Entity(parent=UI, model='quad', color=col, origin=(0.5, 0), position=(AR / 2 - 0.04, y, -0.01), scale=(0.42, 0.022))
    return bg, fg


hud = Entity(parent=UI)
hp_lbl = Text('HEALTH', parent=hud, position=(AR / 2 - 0.46, -0.29), scale=0.9)
hp_bg, hp_bar = bar(-0.33, C('#ef4444'))
v_lbl = Text('VAULT', parent=hud, position=(AR / 2 - 0.46, -0.34), scale=0.9)
v_bg, v_bar = bar(-0.38, C('#f59e0b'))
m_lbl = Text('TIME FREEZE [Q]', parent=hud, position=(AR / 2 - 0.46, -0.39), scale=0.9)
m_bg, m_bar = bar(-0.43, C('#38bdf8'))
for e in (hp_bg, hp_bar, v_bg, v_bar, m_bg, m_bar):
    e.parent = hud
money_t = Text('$0', parent=hud, position=(AR / 2 - 0.04, 0.47), origin=(0.5, 0.5), scale=2.4, color=C('#4ade80'))
wave_t = Text('', parent=hud, position=(AR / 2 - 0.04, 0.4), origin=(0.5, 0.5), scale=1.1, color=C('#cbd5e1'))
ammo_t = Text('20', parent=hud, position=(-AR / 2 + 0.05, -0.42), origin=(-0.5, 0), scale=3)
cross = Text('+', parent=hud, origin=(0, 0), scale=2)
hitmark = Text('x', parent=hud, origin=(0, 0), scale=2.4, color=Color(1, 1, 1, 0))
freeze_ov = Entity(parent=UI, model='quad', scale=(AR * 1.1, 1.1), color=Color(0.15, 0.4, 0.9, 0), z=1)
dmg_ov = Entity(parent=UI, model='quad', scale=(AR * 1.1, 1.1), color=Color(1, 0, 0, 0), z=1)
flash_ov = Entity(parent=UI, model='quad', scale=(AR * 1.1, 1.1), color=Color(1, 1, 1, 0), z=1)
count_t = Text('', parent=UI, origin=(0, 0), y=0.36, scale=5, color=C('#c8f5ff'))
banner_t = Text('', parent=UI, origin=(0, 0), y=0.16, scale=3)
banner_sub = Text('', parent=UI, origin=(0, 0), y=0.09, scale=1.4, color=C('#4ade80'))
combo_t = Text('', parent=UI, origin=(0, 0), y=0.25, scale=4, color=C('#facc15'))
feed_t = Text('', parent=UI, origin=(0, 0), y=-0.08, scale=1.6)

# menu
menu = Entity(parent=UI)
Entity(parent=menu, model='quad', color=Color(0.01, 0.02, 0.05, 0.85), origin=(0.5, 0), position=(AR / 2, 0, 0.5), scale=(AR * 0.5, 1))
Text('TEN SECONDS', parent=menu, origin=(0.5, 0), position=(AR / 2 - 0.06, 0.32), scale=5, color=C('#7dd3fc'))
Text('ZOMBIES ARE ATTACKING THE BANK!', parent=menu, origin=(0.5, 0), position=(AR / 2 - 0.06, 0.22), scale=1.4)
Text('Stop them before they break into the vault.', parent=menu, origin=(0.5, 0), position=(AR / 2 - 0.06, 0.18), scale=1.1, color=C('#cbd5e1'))
Text('WASD  move       Mouse  aim\n'
     'Left click  shoot (hold)\n'
     'Q / Right click  freeze time (again = release)\n'
     'Space  jump      Shift  sprint      R  reload\n\n'
     'Freeze time, fire a volley that hangs in the air,\nthen release it!\n'
     'Red barrels explode.  Headshots hit much harder.',
     parent=menu, origin=(0.5, 0.5), position=(AR / 2 - 0.06, 0.12), scale=1.05, color=C('#e2e8f0'))
last_run_t = Text('', parent=menu, origin=(0.5, 0), position=(AR / 2 - 0.06, -0.24), scale=1.1, color=C('#fca5a5'))
start_btn = Button(parent=menu, text='CLICK TO START', color=C('#38bdf8'), highlight_color=C('#7dd3fc'), text_color=C('#03121c'),
                   scale=(0.42, 0.08), origin=(0.5, 0), position=(AR / 2 - 0.06, -0.33))
pause_ui = Entity(parent=UI, enabled=False)
Entity(parent=pause_ui, model='quad', scale=(AR * 1.1, 1.1), color=Color(0, 0, 0, 0.6))
Text('PAUSED', parent=pause_ui, origin=(0, 0), y=0.08, scale=4)
Text('click to continue', parent=pause_ui, origin=(0, 0), y=-0.02, scale=1.5)


# ======================================================================
# game state
# ======================================================================
class G:
    state = 'menu'
    freeze = False; meter = 10.0; slowmo = 0.0; shake = 0.0
    zombies = []; bullets = []; parts = []; pickups = []; barrels = []; booms = []
    money = 0; kills = 0; wave = 0; to_spawn = 0; spawn_t = 0; break_t = 5.0
    ammo = 20; reload_t = 0; fire_t = 0
    combo = 0; last_kill = -9; t = 0; dmg = 0; flash = 0; last_hurt = -9
    hit_t = 0; banner_t = 0; feed_t = 0; combo_tm = 0; groan_t = 2
    vault_hp = 1000; vault_shake = 0; vault_warn = 0
    yaw = 180.0; pitch = 0.0; px = 0.0; py = 0.0; pz = 10.0; vy = 0.0; on_ground = True; bob = 0.0; hp = 100.0
    showcase = []


MAX_METER, MAG, VAULT_MAX = 10.0, 20, 1000


def clear_world():
    for z in G.zombies: z.destroy()
    for lst in (G.bullets, G.parts, G.pickups, G.barrels, G.booms):
        for o in lst:
            destroy(o['e'])
    G.zombies, G.bullets, G.parts, G.pickups, G.barrels, G.booms = [], [], [], [], [], []


def place_barrels():
    for b in G.barrels:
        destroy(b['e'])
    G.barrels = []
    for (x, z) in [(-8, 0), (8, 1.5), (0, -6), (-16, -11), (16, 11), (-2, 11), (16, -11), (-17, 4)]:
        e = Entity(position=(x, 0, z))
        Entity(parent=e, model=Cylinder(18), scale=(0.84, 1.15, 0.84), color=C('#b91c1c'))
        Entity(parent=e, model=Cylinder(18), y=0.75, scale=(0.86, 0.12, 0.86), color=C('#facc15'))
        G.barrels.append({'e': e, 'x': x, 'z': z, 'dead': False})


def reset_game():
    clear_world()
    G.freeze = False; G.meter = MAX_METER; G.slowmo = 0; G.shake = 0
    G.money = 0; G.kills = 0; G.wave = 0; G.to_spawn = 0; G.break_t = 5.0
    G.ammo = MAG; G.reload_t = 0; G.fire_t = 0; G.combo = 0; G.t = 0; G.last_hurt = -9
    G.vault_hp = VAULT_MAX; G.vault_shake = 0
    G.yaw, G.pitch, G.px, G.py, G.pz, G.vy, G.hp = 180.0, 0.0, 0.0, 0.0, 10.0, 0.0, 100.0
    freeze_ov.color = Color(0.15, 0.4, 0.9, 0); count_t.text = ''
    place_barrels()


def banner(title, sub=''):
    banner_t.text = title; banner_sub.text = sub; G.banner_t = 2.4


def feed(text, col=color.white):
    feed_t.text = text; feed_t.color = col; G.feed_t = 1.2


# ---------- particles / bullets / pickups ----------
def spawn_part(pos, col, speed, life):
    e = Entity(model='cube', position=pos, scale=0.07, color=col, unlit=True)
    v = Vec3(random.uniform(-1, 1), random.uniform(0.1, 0.9), random.uniform(-1, 1)).normalized() * speed * random.uniform(0.4, 1.4)
    G.parts.append({'e': e, 'v': v, 't': 0, 'life': life * random.uniform(0.6, 1.4)})


def spawn_bullet(pos, direction, owner, speed):
    is_p = owner == 'player'
    col = C('#7dd3fc') if is_p else C('#84ff3a')
    e = Entity(position=pos)
    Entity(parent=e, model='sphere', scale=0.12 if is_p else 0.26, color=C('#e0faff') if is_p else C('#d9ff9e'), unlit=True)
    ln = 1.6 if is_p else 1.1
    Entity(parent=e, model='cube', scale=(0.035, 0.035, ln), z=-ln / 2, color=Color(col[0], col[1], col[2], 0.8), unlit=True)
    Entity(parent=e, model='quad', billboard=True, texture='radial_gradient', scale=0.35 if is_p else 0.7, color=Color(col[0], col[1], col[2], 0.8), unlit=True)
    vel = direction.normalized() * speed
    e.look_at(pos + vel)
    G.bullets.append({'e': e, 'vel': vel, 'owner': owner, 'life': 4.0, 'trav': 0.0})


def drop_cash(x, z, v):
    e = Entity(position=(x, 0.7, z))
    Entity(parent=e, model='cube', scale=(0.42, 0.2, 0.26), color=C('#22c55e'))
    Entity(parent=e, model='cube', scale=(0.43, 0.06, 0.27), color=C('#bbf7d0'), unlit=True)
    G.pickups.append({'e': e, 'v': v, 't': random.random() * 6})


def explode(x, y, z):
    snd('boom'); G.shake = max(G.shake, 0.7); G.flash = max(G.flash, 0.35)
    e = Entity(model='sphere', position=(x, y, z), scale=1, color=Color(1, 0.7, 0.3, 0.9), unlit=True)
    G.booms.append({'e': e, 't': 0})
    c = Vec3(x, y, z)
    for i in range(40):
        spawn_part(c, [C('#ff7a1a'), C('#ffd23f'), C('#444444')][i % 3], 11, 0.9)
    for zb in G.zombies:
        if zb.dead: continue
        d = math.hypot(zb.pos.x - x, zb.pos.z - z)
        if d < 5.5:
            dr = Vec3(zb.pos.x - x, 0, zb.pos.z - z)
            damage_zombie(zb, 999 if d < 3.5 else 160, dr if dr.length() > 0.01 else Vec3(1, 0, 0), False)
            if zb.dead:
                zb.vel *= 1.8; zb.vel.y = 8
    for b in G.barrels:
        if not b['dead'] and math.hypot(b['x'] - x, b['z'] - z) < 5:
            b['dead'] = True
            bx, bz = b['x'], b['z']; ent = b['e']
            def chain(bx=bx, bz=bz, ent=ent):
                destroy(ent)
                if G.state in ('play', 'pause'):
                    explode(bx, 0.6, bz)
            invoke(chain, delay=0.15)
    pd = math.hypot(G.px - x, G.pz - z)
    if pd < 4:
        hurt_player(35 if pd < 2 else 15)


# ---------- player ----------
def hurt_player(dmg):
    if G.state != 'play': return
    G.hp -= dmg; G.last_hurt = G.t; G.dmg = 0.5; G.shake = max(G.shake, 0.2); snd('hurt')
    if G.hp <= 0:
        G.hp = 0; game_over('player')


def hurt_vault(dmg, x):
    G.vault_hp -= dmg; G.vault_shake = 0.25
    for _ in range(6):
        spawn_part(Vec3(x, 1.6, -AZ + 0.6), C('#ffd23f'), 4, 0.35)
    snd('hit', 0.6, 0.5)
    if G.vault_warn <= 0:
        feed('THE ZOMBIES ARE ATTACKING THE VAULT!', C('#f87171')); G.vault_warn = 4
    if G.vault_hp <= 0:
        G.vault_hp = 0; game_over('vault')


def shoot():
    if G.reload_t > 0: return
    if G.ammo <= 0:
        start_reload(); return
    G.ammo -= 1
    fwd = camera.forward
    d = Vec3(fwd.x + random.uniform(-0.004, 0.004), fwd.y + random.uniform(-0.004, 0.004), fwd.z + random.uniform(-0.004, 0.004))
    start = camera.world_position + d * 0.9 + camera.right * 0.12 - camera.up * 0.1
    target = camera.world_position + d * 40
    spawn_bullet(start, target - start, 'player', 95)
    snd('shot', 0.5 if G.freeze else 0.8, 1.6 if G.freeze else None)
    gun.z = 0.42; G.pitch -= 0.35; G.shake = max(G.shake, 0.04)
    muzzle.color = Color(0.6, 0.9, 1, 1); muzzle.rotation_z = random.random() * 360
    if G.ammo == 0:
        start_reload()


def start_reload():
    if G.reload_t > 0 or G.ammo == MAG: return
    G.reload_t = 1.0; snd('reload')


def toggle_freeze():
    if G.state != 'play': return
    if G.freeze:
        release(); return
    if G.meter < 1:
        feed('time is recharging...', C('#94a3b8')); return
    G.freeze = True; snd('freeze'); G.flash = 0.25
    freeze_ov.color = Color(0.15, 0.4, 0.9, 0.28)


def release():
    G.freeze = False; snd('release')
    freeze_ov.color = Color(0.15, 0.4, 0.9, 0); count_t.text = ''
    G.shake = max(G.shake, 0.35); G.flash = 0.2
    if sum(1 for b in G.bullets if b['owner'] == 'player') >= 4:
        G.slowmo = max(G.slowmo, 0.6)


# ---------- zombies ----------
def spawn_zombie():
    opts = [s for s in SPAWNS if math.hypot(s[0] - G.px, s[1] - G.pz) > 8] or SPAWNS
    sp = random.choice(opts)
    r = random.random(); t = 'walker'
    if G.wave >= 4 and r < 0.12: t = 'brute'
    elif G.wave >= 3 and r < 0.3: t = 'spitter'
    elif G.wave >= 2 and r < 0.55: t = 'runner'
    z = Zombie(t, random, G.wave)
    z.root.position = Vec3(sp[0], 0, sp[1]); z.last = Vec3(z.root.position)
    G.zombies.append(z)
    door_glow[SPAWNS.index(sp)].color = Color(1, 0.16, 0.16, 0.8)
    for _ in range(10):
        spawn_part(z.root.position + Vec3(0, 1, 0), C('#7cff4a'), 4, 0.5)


def hit_test(z, p):
    if distance(p, z.head_pos()) < 0.21 * z.s:
        return 'head'
    if math.hypot(p.x - z.pos.x, p.z - z.pos.z) < 0.38 * z.s and 0 < p.y < 1.58 * z.s:
        return 'body'
    return None


def damage_zombie(z, dmg, direction, head):
    if z.dead: return
    z.hp -= dmg; z.flash_t = 0.08
    hitmark.color = C('#ff3b3b') if head else color.white; G.hit_t = 0.12
    if z.hp <= 0:
        kill_zombie(z, direction, head)
    else:
        snd('head' if head else 'hit')


def kill_zombie(z, direction, head):
    z.dead = True; G.kills += 1
    snd('kill'); head and snd('head')
    d = Vec3(direction.x, 0, direction.z)
    d = d.normalized() if d.length() > 0.001 else Vec3(1, 0, 0)
    z.vel = d * (7 if head else 5.5); z.vel.y = 4.5
    z.spin = Vec3(-random.uniform(230, 460), random.uniform(-170, 170), random.uniform(-115, 115))
    for gl in z.glows: gl.enabled = False
    for _ in range(20):
        spawn_part(z.pos + Vec3(0, 1.2, 0), C('#b6ff5a') if head else C('#5f9e2f'), 6, 0.7)
    val = z.T['val'] + (100 if head else 0)
    drop_cash(z.pos.x, z.pos.z, val)
    G.combo = G.combo + 1 if G.t - G.last_kill < 1.6 else 1
    G.last_kill = G.t
    feed(('HEADSHOT  ' if head else '') + f'+${val}', C('#facc15') if head else color.white)
    if G.combo >= 2:
        names = {2: 'DOUBLE KILL', 3: 'TRIPLE KILL', 4: 'MEGA KILL', 5: 'ULTRA KILL'}
        bonus = 500 * (G.combo - 1); G.money += bonus
        combo_t.text = names.get(G.combo, f'GODLIKE x{G.combo}'); G.combo_tm = 1.2; combo_t.scale = 5
        feed(f'COMBO +${bonus}', C('#4ade80'))
        G.slowmo = max(G.slowmo, 0.7)


def start_wave():
    G.wave += 1; G.to_spawn = 4 + G.wave * 3; G.spawn_t = 0.3
    extra = {2: '  -  watch out: RUNNERS', 3: '  -  new: ACID SPITTERS'}.get(G.wave, '  -  BRUTES incoming' if G.wave >= 4 else '')
    banner(f'WAVE {G.wave}', f'{G.to_spawn} zombies{extra}')
    snd('wave')


# ======================================================================
# opening screen (always the same)
# ======================================================================
def setup_menu():
    reset_game()
    G.state = 'menu'
    rng = random.Random(1234)
    defs = [('walker', 2.4, 7.4, -30), ('brute', 2.0, 5.0, -22), ('spitter', 5.0, 6.4, -48), ('runner', 3.6, 4.1, -35), ('walker', 0.9, 8.0, -17)]
    G.showcase = []
    for (t, x, z, ry) in defs:
        zb = Zombie(t, rng, 1)
        zb.root.position = Vec3(x, 0, z); zb.root.rotation_y = ry
        G.zombies.append(zb); G.showcase.append(zb)
    menu.enabled = True; hud.enabled = False; gun.enabled = False
    banner_t.text = ''; banner_sub.text = ''; combo_t.text = ''; feed_t.text = ''
    mouse.locked = False
    camera.parent = scene
    camera.position = Vec3(-1.8, 1.55, 10.2)
    camera.look_at(Vec3(0.4, 1.3, 5.6))


def start_game():
    menu.enabled = False; hud.enabled = True; gun.enabled = True
    reset_game()
    G.state = 'play'
    mouse.locked = True
    camera.rotation = Vec3(0, 0, 0)
    banner('ZOMBIES INCOMING!', 'protect the vault and yourself')


start_btn.on_click = start_game


def game_over(reason):
    G.state = 'over'; G.freeze = False; freeze_ov.color = Color(0.15, 0.4, 0.9, 0); count_t.text = ''
    why = 'The zombies broke into the vault' if reason == 'vault' else 'The zombies got you'
    best_file = Path(__file__).resolve().parent / 'ten_seconds_best.txt'
    best = 0
    try:
        best = int(best_file.read_text()) if best_file.exists() else 0
        if G.money > best:
            best_file.write_text(str(G.money))
    except Exception:
        pass
    rec = '   NEW RECORD!' if G.money > best else (f'   best: ${best:,}' if best else '')
    last_run_t.text = f'{why}  -  wave {G.wave}  -  {G.kills} zombies  -  ${G.money:,}{rec}'
    invoke(setup_menu, delay=0)


# ======================================================================
# input
# ======================================================================
def input(key):
    if G.state == 'pause':
        if key in ('left mouse down', 'escape'):
            pause_ui.enabled = False; G.state = 'play'; mouse.locked = True
        return
    if G.state == 'menu':
        if key in ('enter', 'space'):
            start_game()
        return
    if G.state != 'play':
        return
    if key == 'escape':
        G.state = 'pause'; pause_ui.enabled = True; mouse.locked = False
    elif key in ('q', 'right mouse down'):
        toggle_freeze()
    elif key == 'r':
        start_reload()
    elif key == 'space' and G.on_ground:
        G.vy = 7; G.on_ground = False
    elif key == 'left mouse down':
        G.fire_t = 0


# ======================================================================
# update
# ======================================================================
def update():
    dt = min(time.dt, 0.05)
    if G.state == 'menu':
        G.t += dt
        for i, z in enumerate(G.showcase):
            tt = G.t * 1.3 + i * 1.7
            z.shoulders[0].rotation_x = -93 + math.sin(tt) * 7
            z.shoulders[1].rotation_x = -87 + math.sin(tt + 1) * 7
            z.elbows[0].rotation_x = -17 - max(0, math.sin(tt * 1.4)) * 17
            z.elbows[1].rotation_x = -20 - max(0, math.sin(tt * 1.2 + 2)) * 17
            z.head.rotation_z = math.sin(tt * 0.6) * 11 + 4
            z.head.rotation_x = math.sin(tt * 0.9) * 6 - 6
            z.jaw.rotation_x = 14 + abs(math.sin(tt * 2.2)) * 17
            for k, h in enumerate(z.shreds):
                h.rotation_x = 8 + math.sin(tt * 1.5 + k) * 11
            z.model.y = abs(math.sin(tt * 0.5)) * 0.02
        G.groan_t -= dt
        if G.groan_t <= 0:
            G.groan_t = random.uniform(2, 5); snd('groan', 0.5)
        return
    if G.state != 'play':
        return

    G.t += dt
    if G.slowmo > 0: G.slowmo -= dt
    wdt = 0 if G.freeze else dt * (0.3 if G.slowmo > 0 else 1)

    if G.freeze:
        G.meter -= dt
        count_t.text = f'{max(0, G.meter):.1f}'
        count_t.color = C('#ff7a7a') if G.meter < 3 else C('#c8f5ff')
        if G.meter <= 0:
            G.meter = 0; release()
    else:
        G.meter = min(MAX_METER, G.meter + dt * 0.9)

    if G.t - G.last_hurt > 2.5 and G.hp < 100:
        G.hp = min(100, G.hp + 22 * dt)

    # ---- player (always real time) ----
    G.yaw += mouse.velocity[0] * 40
    G.pitch = clamp(G.pitch - mouse.velocity[1] * 40, -85, 85)
    ry = math.radians(G.yaw)
    fx, fz = math.sin(ry), math.cos(ry)
    rx, rz = math.cos(ry), -math.sin(ry)
    mx = (held_keys['w'] - held_keys['s']) * fx + (held_keys['d'] - held_keys['a']) * rx
    mz = (held_keys['w'] - held_keys['s']) * fz + (held_keys['d'] - held_keys['a']) * rz
    ml = math.hypot(mx, mz)
    sprint = held_keys['shift']
    if ml > 0:
        sp = (9.5 if sprint else 6.5) * dt
        G.px += mx / ml * sp; G.pz += mz / ml * sp
        G.bob += dt * (14 if sprint else 10)
    G.px, G.pz = push_out(G.px, G.pz, 0.4, G.py)
    G.vy -= 20 * dt; G.py += G.vy * dt
    ground = floor_under(G.px, G.pz)
    if G.py <= ground:
        G.py = ground; G.vy = 0; G.on_ground = True
    bob = math.sin(G.bob) * 0.05 if (G.on_ground and ml > 0) else 0
    camera.parent = scene
    camera.position = Vec3(G.px, G.py + 1.65 + bob, G.pz)
    camera.rotation = Vec3(G.pitch, G.yaw, 0)
    if G.shake > 0:
        G.shake -= dt; s = min(0.6, G.shake) * 0.12
        camera.position += Vec3(random.uniform(-s, s), random.uniform(-s, s), random.uniform(-s, s))

    # gun
    gun.z += (0.5 - gun.z) * min(1, dt * 14)
    gun.x = 0.24 + math.sin(G.bob * 0.5) * 0.012
    gun.y = -0.22 - (0.12 if G.reload_t > 0 else 0)
    gun.rotation_x = 34 if G.reload_t > 0 else gun.rotation_x * 0.8
    mc = muzzle.color; muzzle.color = Color(mc[0], mc[1], mc[2], max(0, mc[3] - dt * 18))
    if G.reload_t > 0:
        G.reload_t -= dt
        if G.reload_t <= 0: G.ammo = MAG
    if mouse.left:
        G.fire_t -= dt
        if G.fire_t <= 0:
            shoot(); G.fire_t = 0.11

    # pickups
    for p in G.pickups:
        p['t'] += dt; e = p['e']
        e.y = 0.7 + math.sin(p['t'] * 3) * 0.12; e.rotation_y += dt * 120
        d = math.hypot(e.x - G.px, e.z - G.pz)
        if d < 5:
            k = min(1, dt * 9 / max(d, 0.3))
            e.x += (G.px - e.x) * k; e.z += (G.pz - e.z) * k
        if d < 1:
            p['dead'] = True; G.money += p['v']; destroy(e); snd('cash', 0.6)
    G.pickups = [p for p in G.pickups if not p.get('dead')]

    # vault shake
    if G.vault_shake > 0:
        G.vault_shake -= dt; vault_hinge.x = -3 + random.uniform(-0.06, 0.06)
    else:
        vault_hinge.x = -3
    if G.vault_warn > 0: G.vault_warn -= dt

    # frozen: player bullets glide out a few meters and hang
    if G.freeze:
        for b in G.bullets:
            if b['owner'] != 'player' or b['trav'] > 4.5: continue
            st = min(4.5 - b['trav'], b['vel'].length() * dt * 0.25)
            n = b['e'].position + b['vel'].normalized() * st
            if blocked(n.x, n.y, n.z):
                b['trav'] = 99; continue
            b['e'].position = n; b['trav'] += st

    if wdt > 0:
        update_world(wdt)
    update_hud(dt)


def update_world(dt):
    # waves
    if G.wave == 0:
        G.break_t -= dt
        if G.break_t <= 0: start_wave()
    elif G.to_spawn == 0 and all(z.dead for z in G.zombies):
        if G.break_t > 0:
            G.break_t -= dt
            if G.break_t <= 0: start_wave()
        else:
            G.money += 1000; G.vault_hp = min(VAULT_MAX, G.vault_hp + 200); G.hp = 100
            banner(f'WAVE {G.wave} CLEARED!', '+$1,000   vault repaired   next wave soon')
            snd('wave'); G.break_t = 5; place_barrels()
    if G.to_spawn > 0:
        G.spawn_t -= dt
        alive = sum(1 for z in G.zombies if not z.dead)
        if G.spawn_t <= 0 and alive < min(5 + G.wave, 14):
            spawn_zombie(); G.to_spawn -= 1; G.spawn_t = max(0.35, 1.0 - G.wave * 0.06)
    for g in door_glow:
        c = g.color; g.color = Color(c[0], c[1], c[2], max(0, c[3] - dt * 0.8))
    G.groan_t -= dt
    if G.groan_t <= 0:
        G.groan_t = random.uniform(0.8, 2.8)
        if any(not z.dead for z in G.zombies): snd('groan', 0.45)

    # zombies
    eye = Vec3(G.px, G.py + 1.4, G.pz)
    for z in G.zombies:
        p = z.root
        if z.dead:
            z.dead_t += dt
            if not z.landed:
                z.vel.y -= 18 * dt
                p.position += z.vel * dt
                p.rotation += z.spin * dt
                p.x, p.z = push_out(p.x, p.z, 0.3)
                if p.y <= 0.15 and z.vel.y < 0:
                    p.y = 0.15; z.vel = Vec3(0, 0, 0); p.rotation_x = -90; p.rotation_z = 0; z.landed = True
                    for _ in range(8): spawn_part(p.position, C('#888888'), 3, 0.4)
            if z.dead_t > 4:
                p.y -= dt * 0.5
                if z.dead_t > 6:
                    z.destroy(); z.gone = True
            continue
        dx, dz = G.px - p.x, G.pz - p.z
        d = math.hypot(dx, dz) or 0.001
        chase = z.target == 'player' or d < 6
        vx, vz = max(-2.6, min(2.6, p.x)), -AZ + 1.25
        tx, tz = (G.px, G.pz) if chase else (vx, vz)
        gx, gz = tx - p.x, tz - p.z; gd = math.hypot(gx, gz) or 0.001
        reach = 1.05 + 0.35 * z.s if chase else 0.35
        moving = False
        if z.type == 'spitter' and chase:
            if d > 11:
                p.x += gx / gd * z.speed * dt; p.z += gz / gd * z.speed * dt; moving = True
            elif d < 7:
                p.x -= gx / gd * z.speed * dt; p.z -= gz / gd * z.speed * dt; moving = True
            z.spit_t -= dt
            if z.spit_t <= 0:
                mouth = z.head_pos() + Vec3(dx / d * 0.25, -0.05, dz / d * 0.25)
                tgt = Vec3(G.px, G.py + 1.3, G.pz)
                if clear_line(mouth, tgt):
                    aim = (tgt - mouth).normalized() + Vec3(random.uniform(-0.02, 0.02), 0, random.uniform(-0.02, 0.02))
                    spawn_bullet(mouth, aim, 'acid', 13); snd('acid', 0.6)
                    z.swing = 0.35; z.spit_t = random.uniform(2.2, 3.7)
                else:
                    z.spit_t = 0.5
        elif gd > reach:
            sx, sz = gx / gd, gz / gd
            if z.stuck > 0.6:
                sx += -gz / gd * z.side * 1.4; sz += gx / gd * z.side * 1.4
                l = math.hypot(sx, sz); sx /= l; sz /= l
                if z.stuck > 2:
                    z.stuck = 0; z.side *= -1
            p.x += sx * z.speed * dt; p.z += sz * z.speed * dt; moving = True
        else:
            z.atk_t -= dt
            if z.atk_t <= 0:
                z.atk_t = z.T['atk']; z.swing = 0.35
                hurt_player(z.T['dmg']) if chase else hurt_vault(z.T['vdmg'], p.x)
                if G.state != 'play': return
        p.rotation_y = math.degrees(math.atan2(dx, dz) if chase else math.atan2(gx, gz))
        p.x, p.z = push_out(p.x, p.z, 0.42 * z.s)
        for o in G.zombies:
            if o is z or o.dead: continue
            ox, oz = p.x - o.root.x, p.z - o.root.z; od = math.hypot(ox, oz); m = 0.45 * (z.s + o.s)
            if 0.001 < od < m:
                p.x += ox / od * (m - od) * 0.5; p.z += oz / od * (m - od) * 0.5
        prog = math.hypot(p.x - z.last.x, p.z - z.last.z)
        z.stuck = z.stuck + dt if (moving and prog < z.speed * dt * 0.3) else max(0, z.stuck - dt)
        z.last = Vec3(p.x, 0, p.z)
        if moving:
            z.walk += dt * (3 + z.speed * 1.6)
        z.animate(dt, moving, G.t)
    G.zombies = [z for z in G.zombies if not z.gone]

    # bullets
    for b in G.bullets:
        b['life'] -= dt
        if b['life'] <= 0:
            b['dead'] = True; continue
        e = b['e']; step = b['vel'].length() * dt; n = max(1, int(step / 0.3) + 1)
        for _ in range(n):
            if b.get('dead'): break
            e.position += b['vel'] * (dt / n); b['trav'] += step / n
            pos = e.position
            for br in G.barrels:
                if not br['dead'] and math.hypot(pos.x - br['x'], pos.z - br['z']) < 0.5 and pos.y < 1.2:
                    br['dead'] = True; b['dead'] = True; destroy(br['e']); explode(br['x'], 0.6, br['z']); break
            if b.get('dead'): break
            if blocked(pos.x, pos.y, pos.z):
                b['dead'] = True
                for _ in range(5): spawn_part(pos, C('#9ae6ff') if b['owner'] == 'player' else C('#b6ff5a'), 3, 0.3)
                break
            if b['owner'] == 'player':
                for z in G.zombies:
                    if z.dead: continue
                    h = hit_test(z, pos)
                    if h:
                        b['dead'] = True
                        damage_zombie(z, 150 if h == 'head' else 40, b['vel'], h == 'head')
                        for _ in range(7): spawn_part(pos, C('#7cff4a'), 3, 0.35)
                        break
            else:
                if math.hypot(pos.x - G.px, pos.z - G.pz) < 0.5 and G.py < pos.y < G.py + 1.85:
                    b['dead'] = True; hurt_player(10)
                    for _ in range(8): spawn_part(pos, C('#84ff3a'), 3, 0.4)
                    if G.state != 'play': return
    for b in G.bullets:
        if b.get('dead'): destroy(b['e'])
    G.bullets = [b for b in G.bullets if not b.get('dead')]

    # particles & explosions
    for p in G.parts:
        p['t'] += dt; p['v'].y -= 14 * dt; e = p['e']
        e.position += p['v'] * dt
        if e.y < 0.03:
            e.y = 0.03; p['v'] *= 0.5; p['v'].y *= -0.3
        e.scale = max(0.005, 0.07 * (1 - p['t'] / p['life']))
        if p['t'] > p['life']:
            p['dead'] = True; destroy(e)
    G.parts = [p for p in G.parts if not p.get('dead')]
    for b in G.booms:
        b['t'] += dt; k = b['t'] / 0.5
        b['e'].scale = 1 + k * 5; b['e'].color = Color(1, 0.7, 0.3, max(0, 0.9 * (1 - k)))
        if k >= 1:
            b['dead'] = True; destroy(b['e'])
    G.booms = [b for b in G.booms if not b.get('dead')]


def update_hud(dt):
    money_t.text = f'${G.money:,}'
    wave_t.text = f'WAVE {G.wave}   -   {G.kills} zombies'
    ammo_t.text = '...' if G.reload_t > 0 else str(G.ammo)
    hp_bar.scale_x = 0.42 * max(0, G.hp) / 100
    v_bar.scale_x = 0.42 * max(0, G.vault_hp) / VAULT_MAX
    m_bar.scale_x = 0.42 * G.meter / MAX_METER
    m_bar.color = C('#f0abfc') if G.freeze else (C('#475569') if G.meter < 1 else C('#38bdf8'))
    if G.hit_t > 0:
        G.hit_t -= dt
        if G.hit_t <= 0: hitmark.color = Color(1, 1, 1, 0)
    if G.banner_t > 0:
        G.banner_t -= dt
        if G.banner_t <= 0: banner_t.text = ''; banner_sub.text = ''
    if G.feed_t > 0:
        G.feed_t -= dt
        if G.feed_t <= 0: feed_t.text = ''
    if G.combo_tm > 0:
        G.combo_tm -= dt; combo_t.scale = 4 + max(0, G.combo_tm - 0.9) * 4
        if G.combo_tm <= 0: combo_t.text = ''
    if G.dmg > 0: G.dmg -= dt
    if G.flash > 0: G.flash -= dt
    dmg_ov.color = Color(1, 0, 0, min(0.5, max(0, G.dmg)))
    flash_ov.color = Color(1, 1, 1, min(0.6, max(0, G.flash * 2)))


setup_menu()
app.run()
